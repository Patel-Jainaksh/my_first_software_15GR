# service/log_notifier.py

socketio_instance = None

def init_notifier(socketio):
    global socketio_instance
    socketio_instance = socketio

def emit_from_queue(emit_queue):
    while True:
        log = emit_queue.get()
        if socketio_instance:
            socketio_instance.emit('new_log', log, namespace='/logs')

# ✅ New helper for recording events
def emit_recording_event(camera_id, status):
    if socketio_instance:
        socketio_instance.emit('recording_event', {
            "camera_id": camera_id,
            "status": status  # "started" or "stopped"
        }, namespace='/recordings')

def emit_camera_status(camera_id, status):
    if socketio_instance:
        socketio_instance.emit('camera_status', {
            "camera_id": camera_id,
            "status": status
        }, namespace='/cameras')

def emit_log_event(log):
    if socketio_instance:
        socketio_instance.emit('new_log', log, namespace='/logs')

